//********************************************************************
//*                      EEE3017W C EXAMPLES                         *
//*                         LCD MODULE                               *
//*==================================================================*
//* WRITTEN BY:    Copyright (C) Samuel Ginsberg 2004                *
//* PORTED TO STM32F0 dev board by James Gowans, 2014                *
//* MODIFIED BY:   Robyn Verrinder                                   *
//* DATE CREATED:  2004                                              *
//* PORTED:		   2014												 *
//* MODIFIED:      28-07-2015                                        *
//*==================================================================*                                                                  
//* PROGRAMMED IN: ECLIPSE IDE Luna Service Release 1 (4.4.1)        *
//* DEV. BOARD:    UCT STM32 Development Board                       *
//*==================================================================*                                                                 
//* DESCRIPTION:   This code contains common functions to communicate*
//*                with the LCD module connected to the GT16 uC.     *
//*==================================================================*
//* LCD SETUP:     - 4 bit mode      (Upper 4 data lines D4-D7 used) *
//*                - Two lines used                                  *
//*                - Flashing cursor                                 *
//*==================================================================*
//* CONNECTIONS:                                                     *
//*------------------------------------------------------------------*
//* LCD PINS   | NAME                    | CONNECTED TO              *
//*------------------------------------------------------------------*
//* 1............VSS.......................GND                       *
//* 2............VDD.......................+5V                       *
//* 3............CONTRAST..................POT 2                     *
//* 4............RS  - Register Select.....PC14 (LCD_RS)             *
//* 5............RW  - Read/Write..........GND                       *
//* 6............E   - Enable..............PC15 (LCD_E)              *
//* 7............D0  - Data line 0.........GND                       * 
//* 8............D1  - Data line 1.........GND                       * 
//* 9............D2  - Data line 2.........GND                       * 
//* 10...........D3  - Data line 3.........GND                       * 
//* 11...........D4  - Data line 4.........PB8  (LCD_D4)             *
//* 12...........D5  - Data line 5.........PB9  (LCD_D5)             *
//* 13...........D6  - Data line 6.........PA12 (LCD_D6)             *
//* 14...........D7  - Data line 7.........PA15 (LCD_D7)             *
//* 15...........CATHLED...................NC                        *
//* 16...........ANODELED..................NC                        *
//********************************************************************
// INCLUDE FILES
//====================================================================
#include "lcd_stm32f0.h"
//====================================================================
// GLOBAL CONSTANTS
//====================================================================
enum TypeOfCharacter
{
	COMMAND 	= 0,		// Command
	TEXT 		= 1			// Text
};
//====================================================================
// FUNCTION DECLARATIONS 
//====================================================================
static void delay(uint32_t microseconds);
static void pulse_strobe(void);
static void lcd_put_char(uint8_t character, enum TypeOfCharacter ch_type);
static void lcd_write4bits(uint8_t value);
//====================================================================
// WRITE A STRING TO THE LCD - lcd_string(ptr_String)
//====================================================================
// DESCRIPTION: Writes a string to the LCD
//====================================================================
void lcd_string(uint8_t *string_to_print)
{
	uint32_t count=0;
	while (string_to_print[count]!= 0)			// Until the null terminator is reached
	{
		lcd_put_char(string_to_print[count], TEXT);	// Write each character to LCD
		delay(43); 								// a DRAM write requires at least 43 us execution time
		count++;
	}
}
//====================================================================
// WRITE TWO LINES TO THE LCD - lcd_two_line_write(strline1ptr,strline2ptr)
//====================================================================
// DESCRIPTION: Writes two lines to the LCD
//====================================================================
void lcd_two_line_write(uint8_t* line1, uint8_t* line2)
{
	lcd_command(LCD_CLEAR_DISPLAY);		// Clear the LCD screen
	lcd_string(line1);					// Write the first line to the LCD
	lcd_command(LCD_GOTO_LINE_2);		// Move to the 2nd line
	lcd_string(line2);					// Write the second line to the LCD
}
//====================================================================
// INITIALISE LCD - lcd_init()
//====================================================================
// DESCRIPTION: This function sets up the port lines for the LCD and
//              intialises the module for use.
//====================================================================
// LCD SETUP:     - 4 bit mode      (Upper 4 data lines D4-D7 used)
//                - Two lines used
//                - Flashing cursor
//====================================================================
void lcd_init(void)
{
 // Connect the system clock to ports A,B & C
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOBEN;
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

  // Set the relevant pins to outputs
	GPIOC->MODER |= GPIO_MODER_MODER14_0; 	// (LCD_RS)
	GPIOC->MODER |= GPIO_MODER_MODER15_0; 	// (LCD_E)

	GPIOB->MODER |= GPIO_MODER_MODER8_0; 	// (LCD_D4)
	GPIOB->MODER |= GPIO_MODER_MODER9_0; 	// (LCD_D5)

	GPIOA->MODER |= GPIO_MODER_MODER12_0; 	// (LCD_D6)
  	GPIOA->MODER |= GPIO_MODER_MODER15_0;	// (LCD_D7)

  	delay(30000); 							// allow the LCD 30 ms power up time
  // in case in 2nd nibble of 4 bit tansfer, this goes to 1st nibble
  // if byte in 8-bit mode, keeps in 8-bit mode
  	lcd_write4bits(0x03);

  	delay(4100);

  	lcd_write4bits(0x03);  // garanteed to be byte of 8-bit data for first byte of 4-bit.

  	delay(39);

  	lcd_write4bits(0x03); // necessary in case this is the 2nd nibble of 4-bit transfer.

  	delay(39);
  // switch to 4-bit. This will latch in a byte as it's garanteed to now be in 8-bit

  	lcd_write4bits(0x02);

  	delay(39);
  	lcd_command(LCD_FOUR_BIT_TWO_LINE_MODE); 		// 0x28
  	lcd_command(LCD_DISPLAY_OFF); 					// 0x08
  	lcd_command(LCD_CLEAR_DISPLAY); 				// 0x01
  	lcd_command(LCD_DISPLAY_ON); 					// 0x0C
}

//====================================================================
// SEND COMMAND CODE TO LCD - lcd_command(command)
//====================================================================
// DESCRIPTION: This function sends a command to the LCD. Care is taken 
//              not to interfere with the other lines on the port.
//
//              As we are using a microcontroller to control the LCD
//              we use 4-bit mode to save on number of lines used to
//              connect to the LCD. This means that an 8-bit command
//              must be split into two sets of 4-bits (upper and lower)
//              These sets must be transmitted 
//====================================================================
// USEFUL COMMANDS:
//                  - POWER_UP:      Power up initialization for the lcd
//                  - FOURBIT_MODE:  Sets LCD for 4-bit mode
//                  - TWOLINE_MODE:  Sets up 2 lines and character size
//                  - SETUP_CURSOR:  Turn display on and set up cursor
//                  - CLEAR:         Clear screen
//                  - CURSOR_HOME:   Cursor home
//                  - LINE_TWO:      Line 2
//
//====================================================================
void lcd_command (enum lcdcommand command)
{
	lcd_put_char((uint8_t)command, COMMAND);
	delay(1530); 							// 1.53 ms is the maximum delay we should need for any command.
  // TODO: fix the above to have variable lengths as required by different commands.
}
//====================================================================
// WRITE A SINGLE CHARACTER TO THE LCD - lcd_put_char(character)
//====================================================================
// DESCRIPTION: Puts a single character on the LCD at the next position
//              on the screen. The character to be printed is in the input
//              parameter. For numbers, letters and other common characters
//              the ASCII code will produce correct display.
//
//              Refer to the Hitachi HD44780 datasheet for full character
//              set information.
//====================================================================
static void lcd_put_char(uint8_t character, enum TypeOfCharacter ch_type)
{
    if 		(ch_type == TEXT)
    {
        GPIOC->BSRR |= GPIO_BSRR_BS_14;		// pull Register Select (PC14) HIGH
    }
    else if (ch_type == COMMAND)
    {
        GPIOC->BSRR |= GPIO_BSRR_BR_14;		// pull Register Select (PC14) LOW
    }

    lcd_write4bits(character >> 4);			// Write upper nibble
    lcd_write4bits(character);				// Write lower nibble
}
//====================================================================
// WRITE A SINGLE CHARACTER TO THE LCD - lcd_write4bits(character)
//====================================================================
// DESCRIPTION: This function outputs the lower 4 bits onto the data lines.
//
//              As we are using a microcontroller to control the LCD
//              we use 4-bit mode to save on number of lines used to
//              connect to the LCD. This means that an 8-bit command
//              must be split into two sets of 4-bits (upper and lower)
//              The LCD data lines are changed one line at a time
//====================================================================
static void lcd_write4bits(uint8_t character)
{
  // lower nibble to data lines
  //
	if ((character & 0x08) != 0)			// If bit 3 of the char is set then
	{
		GPIOA->BSRR |= GPIO_BSRR_BS_15;		// pull LCD-D7 HIGH (1)
	}
	else									// If bit 3 of the char is clear then
	{
		GPIOA->BSRR |= GPIO_BSRR_BR_15;		// pull LCD-D7 LOW  (0)
	}

	if ((character & 0x04) != 0) 			// If bit 2 of the char is set then
	{
		GPIOA->BSRR |= GPIO_BSRR_BS_12;		// pull LCD-D6 HIGH (1)
	}
	else									// If bit 2 of the char is clear then
	{
		GPIOA->BSRR |= GPIO_BSRR_BR_12;		// pull LCD-D6 LOW  (0)
	}

	if ((character & 0x02) != 0)			// If bit 1 of the char is set then
	{
		GPIOB->BSRR |= GPIO_BSRR_BS_9;		// pull LCD-D5 HIGH (1)
	}
	else								    // If bit 1 of the char is clear then
	{
		GPIOB->BSRR |= GPIO_BSRR_BR_9;		// pull LCD-D5 LOW  (0)
	}

	if ((character & 0x01) != 0)			// If bit 0 of the char is set then
	{
		GPIOB->BSRR |= GPIO_BSRR_BS_8;		// pull LCD-D4 HIGH (1)
	}
	else									// If bit 0 of the char is clear then
	{
		GPIOB->BSRR |= GPIO_BSRR_BR_8;		// pull LCD-D4 LOW  (0)
	}
	pulse_strobe ();
}

//====================================================================
// LOOP DELAY - delay()
//====================================================================
// DESCRIPTION: A delay used by the LCD functions. An approximate delay in ms
//====================================================================
static void delay(uint32_t microseconds)
{
	volatile uint32_t counter = 0;
	microseconds *= 3;
	for(; counter<microseconds; counter++)
	{
		__asm("nop");
		__asm("nop");
	}
}
//====================================================================
// PULSE STROBE - pulse_strobe()
//====================================================================
// DESCRIPTION: Pulse the strobe line of the LCD to indicate that data is ready.
//====================================================================
static void pulse_strobe(void)
{
	delay(1);							// Delay 1 ms
	GPIOC->BSRR |= GPIO_BSRR_BS_15;		// Pull Enable (PC15) HIGH
	delay(1);							// Delay
	GPIOC->BSRR |= GPIO_BSRR_BR_15;		// Pull Enable (PC15) LOW
	delay(1);							// Delay 1 ms
}                     

//********************************************************************
// END OF PROGRAM
//********************************************************************
