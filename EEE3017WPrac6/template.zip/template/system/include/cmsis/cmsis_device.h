//
// This file is part of the µOS++ III distribution.
// Copyright (c) 2014 Liviu Ionescu.
//

#ifndef STM32F0_CMSIS_DEVICE_H_
#define STM32F0_CMSIS_DEVICE_H_

#include "stm32f0xx.h"

#endif // STM32F0_CMSIS_DEVICE_H_
